
    pygame.key.set_repeat(100, 100)