import os

data_root = r'E:\Documents\CS106\Assignment3\data\kplib-master'

def rename_subfolders(root_folder):
    for root, dirs, files in os.walk(root_folder):
        for dir_name in dirs:
            dir_path = os.path.join(root, dir_name)
            sub_folders = os.listdir(dir_path)            
            count = 1
            for sub_folder in sub_folders:
                if sub_folder.startswith('n') and sub_folder[1:].isdigit():
                    print(sub_folder)
                    old_path = os.path.join(dir_path, sub_folder)
                    new_folder = str(count)
                    new_path = os.path.join(dir_path, new_folder)
                    os.rename(old_path, new_path)
                    print(f'Thư mục {old_path} đã được đổi thành {new_path}')   
                    count += 1
rename_subfolders(data_root)
print("Đã sửa tên thư mục con xong.")
